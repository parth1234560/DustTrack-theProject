import os
import urllib.parse
from datetime import datetime, timezone

import boto3

dynamodb = boto3.resource("dynamodb")
inspections = dynamodb.Table(os.environ["INSPECTIONS_TABLE"])

def handler(event, context):
    step = os.environ.get("STEP_NAME", "Unknown")
    now = datetime.now(timezone.utc).isoformat()

    detail = event.get("detail", {})
    encoded_key = detail.get("object", {}).get("key", "")
    photo_key = urllib.parse.unquote_plus(encoded_key)
    inspection_id = None

    parts = photo_key.split("/")
    if len(parts) >= 3 and parts[0] == "inspections":
        inspection_id = parts[1]

    if step == "validate_input":
        if not inspection_id:
            raise ValueError("Could not derive inspection ID from S3 object key")

        inspections.update_item(
            Key={"inspectionId": inspection_id},
            UpdateExpression="SET #status = :status, processingStartedAt = :now",
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={
                ":status": "PROCESSING",
                ":now": now,
            },
        )

        return {
            "step": step,
            "status": "ok",
            "inspectionId": inspection_id,
            "photoKey": photo_key,
        }

    inspection_id = event.get("validation", {}).get("inspectionId", inspection_id)

    if step == "publish_work_list":
        if not inspection_id:
            raise ValueError("Missing inspection ID for publish step")

        inspections.update_item(
            Key={"inspectionId": inspection_id},
            UpdateExpression="SET #status = :status, completedAt = :now, workflowResult = :result",
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={
                ":status": "COMPLETED",
                ":now": now,
                ":result": "MVP workflow completed. Replace placeholder AI/weather/scoring handlers with Abdul's final logic.",
            },
        )

        return {
            "step": step,
            "status": "ok",
            "inspectionId": inspection_id,
            "message": "Inspection marked COMPLETED",
        }

    return {
        "step": step,
        "status": "ok",
        "inspectionId": inspection_id,
        "message": f"{step} completed with MVP placeholder logic"
    }
